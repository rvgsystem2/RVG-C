<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center bg-white shadow-md px-6 py-4 rounded-lg">
            <h2 class="font-bold text-2xl text-gray-800">
                <?php echo e(__('User Management')); ?>

            </h2>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create users')): ?>
                <a href="<?php echo e(route('user.create')); ?>"
                    class="px-5 py-2 bg-gradient-to-r from-[#c21108] to-[#000308] text-white font-semibold rounded-lg shadow-md hover:from-[#000308] hover:to-[#c21108] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#c21108] transition duration-300 ease-in-out">
                    + Create
                </a>
            <?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <!-- ✅ Success Alert -->
            <?php if(session('success')): ?>
                <div class="flex items-center bg-green-100 text-green-700 px-4 py-3 rounded-lg mb-6 shadow-md">
                    <svg class="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span><?php echo e(session('success')); ?></span>
                </div>
            <?php endif; ?>

            <!-- ✅ User Table -->
            <div class="bg-white shadow-xl rounded-2xl p-6 border border-gray-100">
                <h2 class="text-2xl font-bold text-gray-800 mb-6">👥 User Management</h2>

                <div class="overflow-x-auto rounded-lg border border-gray-200">
                    <table class="w-full text-sm text-left text-gray-800">
                        <thead
                            class="bg-gradient-to-r from-gray-100 to-gray-200 text-gray-700 uppercase font-semibold text-xs">
                            <tr>
                                <th class="px-6 py-4 border-b">ID</th>
                                <th class="px-6 py-4 border-b">Name</th>
                                <th class="px-6 py-4 border-b">Email</th>
                                <th class="px-6 py-4 border-b">PhoneNumber</th>
                                <th class="px-6 py-4 border-b">Roles</th>
                                <th class="px-6 py-4 border-b">Permissions</th>
                                <th class="px-6 py-4 border-b">Date & Time</th>
                                <th class="px-6 py-4 border-b text-center">Actions</th>
                            </tr>
                        </thead>

                        <tbody class="bg-white divide-y divide-gray-100">
                            <?php $__empty_1 = true; $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-gray-50 transition">
                                    <td class="px-6 py-4"><?php echo e($user->id); ?></td>
                                    
                                    <td class="px-6 py-4 font-medium text-gray-900">
                                        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Super Admin')): ?>
                                            <a href="<?php echo e(route('dm.show', $user->id)); ?>"
                                                class="text-indigo-600 hover:underline">
                                                <?php echo e($user->name); ?>

                                            </a>
                                        <?php else: ?>
                                            <?php echo e($user->name); ?>

                                        <?php endif; ?>
                                    </td>

                                    <td class="px-6 py-4"><?php echo e($user->email); ?></td>
                                    <td class="px-6 py-4"><?php echo e($user->phone_number ?? 'N/A'); ?></td>
                                    <td class="px-6 py-4">
                                        <span class="text-indigo-700 text-sm">
                                            <?php echo e($user->roles->pluck('name')->implode(', ') ?: '—'); ?>

                                        </span>
                                    </td>
                                    <td class="px-6 py-4">
                                        <?php if($user->permissions->isNotEmpty()): ?>
                                            <span class="text-sm text-gray-600 leading-snug">
                                                <?php echo e($user->permissions->pluck('name')->implode(', ')); ?>

                                            </span>
                                        <?php else: ?>
                                            <span class="text-gray-400 italic">No Permissions</span>
                                        <?php endif; ?>
                                    </td>

                                    <td class="px-6 py-4">
                                        <?php echo e($user->created_at->format('d-M-Y h:i')); ?>

                                    </td>
                                    
                                    <td class="px-6 py-4 text-center">
    <div class="flex justify-center flex-wrap gap-2">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit users')): ?>
            <a href="<?php echo e(route('user.edit', $user->id)); ?>"
               class="bg-yellow-500 hover:bg-yellow-600 text-white text-xs px-4 py-2 rounded-md shadow transition">✏️ Edit</a>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete users')): ?>
            <a href="<?php echo e(route('user.delete', $user->id)); ?>"
               class="bg-red-500 hover:bg-red-600 text-white text-xs px-4 py-2 rounded-md shadow transition">🗑️ Delete</a>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('assign permissions user')): ?>
            <a href="<?php echo e(route('user.permission.form', $user->id)); ?>"
               class="bg-blue-600 hover:bg-blue-700 text-white text-xs px-4 py-2 rounded-md shadow transition">🔒 Assign</a>
        <?php endif; ?>

        
        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Super Admin')): ?>
            <?php if(auth()->id() !== $user->id): ?>
                <a href="<?php echo e(route('admin.dm.edit', $user->id)); ?>"
                   class="bg-indigo-600 hover:bg-indigo-700 text-white text-xs px-4 py-2 rounded-md shadow transition">
                    ⚙️ Assign DM Access
                </a>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</td>

                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center py-6 text-gray-500 text-base">No users found.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\realvictory\RVG-C\resources\views/user/index.blade.php ENDPATH**/ ?>