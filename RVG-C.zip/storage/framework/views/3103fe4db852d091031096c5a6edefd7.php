<?php $__env->startSection('content'); ?>


    <div class="container-flued bg-white p-0">


        <!-- Navbar & Hero Start -->
        <div class="container-flued position-relative p-0">


            <div class="container-fluid pb-5 pt-5 custom-color" id="">
                <div class="container px-lg-5 pt-5">
                    <?php $__empty_1 = true; $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="row g-5 align-items-end">
                            <div class="col-lg-6 text-center text-lg-start">
                                <h2 class="text-white mb-4 animated slideInDown"><?php echo e($banner->title); ?></h2>
                                <p class="text-white pb-3 animated slideInDown"><?php echo e($banner->subtitle); ?></p>
                                <a href="<?php echo e(url('packages')); ?>"
                                    class="btn btn-dark py-sm-3 px-sm-5 rounded-pill me-3 animated slideInLeft">Buy More Packages
                                    </a>
                                <a href="<?php echo e(url('contact')); ?>"
                                    class="btn btn-light py-sm-3 px-sm-5 rounded-pill animated slideInRight text-danger">Contact
                                    Us</a>
                            </div>
                            <div class="col-lg-6 text-center text-lg-start pt-5">
                                <img class="img-fluid animated zoomIn"
                                    src="<?php echo e(asset('storage/' . ($banner->image ?? 'front-asset/img/hero.png'))); ?>"
                                    alt="<?php echo e($banner->img_alt_text ?? 'Banner Image'); ?>">
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-white">No banners available</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <!-- Navbar & Hero End -->

        <!-- About Start -->
        <div class="container-fluid lg:py-5 md:py-4 sm:py-3 py-2">
            <?php $__empty_1 = true; $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="container py-5 px-lg-5">
                    <p class="section-title text-center align-items-center"><?php echo e($about->title); ?></p>
                    <div class="row g-5 align-items-center">

                        <!-- Image Column: Order-1 on mobile, Order-2 on large screens -->
                        <div class="col-lg-6 order-1 order-lg-2">
                            <img class="img-fluid wow zoomIn" data-wow-delay="0.5s"
                                src="<?php echo e(asset('storage/' . ($about->image ?? 'front-asset/img/about.png'))); ?>"
                                alt="<?php echo e($about->image_alt ?? 'Abouts Image'); ?>">
                        </div>

                        <!-- Content Column: Order-2 on mobile, Order-1 on large screens -->
                        <div class="col-lg-6 order-2 order-lg-1 wow fadeInUp" data-wow-delay="0.1s">

                            <h2 class="mb-5"><?php echo e($about->subtitle); ?></h2>
                            <p class="mb-4"><?php echo $about->description; ?></p>



                            <a href="<?php echo e(url('about')); ?>" class="btn btn-custom py-sm-3 px-sm-5 rounded-pill mt-3">Read
                                More</a>
                        </div>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </div>

        <!-- About End -->


        
        <?php echo $__env->make('front.counter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        

        <!-- PRODUCT Start -->
        <?php echo $__env->make('front.product', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <!-- Feature End -->


        <!-- Service Start -->
        <div class="container-fluid lg:py-5 md:py-4 sm:py-3 bg-light">
            <div class="container py-3 px-lg-5">
                <div class="text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
                    <p class="section-title text-dark justify-content-center"><span></span>Our Services<span></span></p>
                    <h2 class="display-6">What Solutions We Provide</h2>
                    <p class="text-muted">Discover the wide range of digital, creative, and strategic solutions we offer to
                        elevate your business.</p>
                </div>

                <div class="row g-4">
                    <?php $__empty_1 = true; $__currentLoopData = $serviceCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $__currentLoopData = $category->serviceDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                                <div class="bg-white shadow rounded-4 text-center h-100 p-4 service-card transition-scale">
                                    <div class="service-icon mb-3 text-primary fs-1">
                                        <i class="<?php echo e($category->icon); ?>"></i>
                                    </div>
                                    <h5 class="fw-bold mb-2"><?php echo e($category->name); ?></h5>
                                    <p class="text-muted mb-4">
                                        <?php echo e(\Illuminate\Support\Str::limit($detail->sort_description, 120)); ?></p>
                                    <div class="d-flex justify-content-center gap-3">
                                        <a href="<?php echo e(route('servicedetail', $category->slug)); ?>"
                                            class="btn btn-success btn-sm px-4">Read More</a>
                                        <a href="<?php echo e(route('contact')); ?>" class="btn btn-custom btn-sm px-4">Contact Us</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-center">
                            <p class="text-muted">No services available at the moment.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <!-- Service End -->


        <!-- Service End -->

        <!-- Projects Start -->
        <div class="container-fluid lg:py-5 md:py-4 sm:py-py-3 py-2 bg-light">
            <div class="container py-5 px-lg-5">
                <div class="text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
                    <p class="section-title text-dark justify-content-center"><span></span>Our Projects<span></span></p>
                    <h2 class="display-6">Recently Completed Projects</h2>
                    <p class="text-muted">Explore a few of our successful project deployments for different clients.</p>
                </div>

                <!-- Tab-style Filter Buttons -->
                <div class="row mb-4 wow fadeInUp" data-wow-delay="0.2s">
                    <div class="col-12 d-flex justify-content-center flex-wrap gap-2" id="portfolio-flters">
                        <button class="btn btn-outline-dark active" data-filter="*">All</button>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button class="btn btn-outline-dark"
                                data-filter=".<?php echo e(Str::slug($category)); ?>"><?php echo e($category); ?></button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <!-- Projects Grid -->
                <div class="row g-4 portfolio-container">
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $projectImages = json_decode($project->project_images, true) ?? [];

                            // Ensure thumb_image is shown first, then rest of project_images (excluding duplicate of thumb)
                            $images = array_unique(array_merge([$project->thumb_image], $projectImages));
                            $firstImage = $images[0];
                        ?>
                        
                        <div class="col-lg-4 col-md-6 portfolio-item <?php echo e(Str::slug($project->project_category_name)); ?> wow fadeInUp"
                            data-wow-delay="0.1s">
                            <div class="card shadow-sm border-0 h-100 project-card overflow-hidden rounded-4">
                                <div class="position-relative">
                                    <img src="<?php echo e(asset('storage/' . $firstImage)); ?>" class="card-img-top"
                                        alt="<?php echo e($project->title); ?>" style="height: 240px; object-fit: cover;">
                                    <div class="portfolio-overlay d-flex align-items-center justify-content-center gap-2">
                                        <?php if(count($images)): ?>
                                            <a href="<?php echo e(asset('storage/' . $images[0])); ?>"
                                                data-lightbox="portfolio-<?php echo e($project->id); ?>"
                                                class="btn btn-light btn-sm rounded-circle">
                                                <i class="fa fa-eye text-danger"></i>
                                            </a>

                                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($index > 0): ?>
                                                    <a href="<?php echo e(asset('storage/' . $img)); ?>"
                                                        data-lightbox="portfolio-<?php echo e($project->id); ?>" class="d-none"></a>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                        <?php if($project->project_url): ?>
                                            <a href="<?php echo e($project->project_url); ?>" target="_blank"
                                                class="btn btn-light btn-sm rounded-circle">
                                                <i class="fa fa-link text-dark"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="card-body text-center">
                                    <p class="text-danger small fw-semibold mb-1"><?php echo e($project->project_category_name); ?></p>
                                    <h5 class="card-title mb-0"><?php echo e($project->title); ?></h5>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <!-- Projects End -->




        <!-- Testimonials Start -->
        <div class="container-fluid lg:py-5 md:py-4 sm:py-3 py-2 bg-light">
            <div class="container">
                <div class="text-center mx-auto mb-5" style="max-width: 600px;">
                    <h5 class="text-dark">Testimonials</h5>
                    <h2 class="display-6 mb-4">What Our Clients Say!</h2>
                    <p class="text-muted">Real stories from real people. See how our service is making an impact.</p>
                </div>

                <?php if($testimonials->count()): ?>
                    <div class="owl-carousel testimonial-carousel">
                        <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="testimonial-item bg-white rounded-4 shadow-sm p-4 border border-light">
                                <div class="d-flex align-items-center mb-3">
                                    <img class="img-fluid rounded-circle border border-3 border-dark"
                                        src="<?php echo e(asset('storage/' . $testimonial->image)); ?>"
                                        alt="<?php echo e($testimonial->name); ?>"
                                        style="width: 65px; height: 65px; object-fit: cover;">
                                    <div class="ps-3">
                                        <h5 class="mb-1"><?php echo e($testimonial->name); ?></h5>
                                        <span class="text-muted small"><?php echo e($testimonial->designation); ?></span><br>
                                        <span class="text-muted small"><?php echo e($testimonial->company); ?></span>
                                    </div>
                                </div>
                                <p class="fst-italic text-dark mb-0">
                                    <i class="fas fa-quote-left me-2 text-dark"></i><?php echo e($testimonial->message); ?>

                                </p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <p class="text-center text-muted">No testimonials found.</p>
                <?php endif; ?>
            </div>
        </div>
        <!-- Testimonials End -->




        <!-- Contact Start -->
        <?php echo $__env->make('front.contentcomponent', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        


        <div class="container-fluid lg:py-5 md:py-4 sm:py-3 py-2 bg-light">
            <div class="container bg-light py-5 px-4 px-lg-5 rounded shadow text-center">
                <!-- Text Content -->
                <div class="mb-4">
                    <h2 class="fw-bold mb-3">Have a project in mind? Let's talk now.</h2>
                    <p class="text-muted mb-0">Sure, let’s discuss your project idea in detail. What’s next?</p>
                </div>

                <!-- Buttons Row -->
                <div class="container">
                    <div class="row justify-content-center g-3 mb-3 text-center">

                        <!-- Call Now Button -->
                        <div class="col-12 col-md-auto">
                            <a href="tel:+918299012292" class="btn btn-success w-100 px-4 py-3 rounded-pill shadow-sm">
                                <i class="fa fa-phone-alt me-2"></i> Call Now
                            </a>
                        </div>

                        <!-- WhatsApp Button -->
                        <div class="col-12 col-md-auto">
                            <a href="https://wa.me/+918299012292" target="_blank"
                                class="btn btn-success w-100 px-4 py-3 rounded-pill fw-semibold shadow-sm">
                                <i class="fab fa-whatsapp me-2"></i> Let's Chat on WhatsApp
                            </a>
                        </div>

                    </div>
                </div>


            </div>
        </div>




    </div>

    <!-- jQuery (required) -->

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Initialize Isotope -->
    <script>
        $(window).on('load', function() {
            var $grid = $('.portfolio-container').isotope({
                itemSelector: '.portfolio-item',
                layoutMode: 'fitRows'
            });

            $('#portfolio-flters').on('click', 'button', function() {
                $('#portfolio-flters button').removeClass('active');
                $(this).addClass('active');
                var filterValue = $(this).attr('data-filter');
                $grid.isotope({
                    filter: filterValue
                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('component.main', ['seos' => $seos], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\realvictory\RVG-C\resources\views/front/index.blade.php ENDPATH**/ ?>