<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div class="container-fluid custom-color  my-lg-5 py-md-4 py-sm-3 py-2">
        <div class="container text-center py-5">
            <h1 class="display-3 text-white mb-3 animated slideInDown">Projects</h1>
            <nav aria-label="breadcrumb" class="animated slideInDown">
                <ol class="breadcrumb justify-content-center mb-0">
                    <li class="breadcrumb-item"><a class="text-white" href="#">Home</a></li>
                    <li class="breadcrumb-item text-white active" aria-current="page"><a
                            href="<?php echo e(route('contact')); ?>">Projects</a></li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="container-fluid bg-white p-0">


        <!-- Projects Start -->
        <div class="container-flued lg:py-5 md:py-4 sm:py-3 py-2">
            <div class="container py-5 px-lg-5">
                <div class="wow fadeInUp" data-wow-delay="0.1s">
                    <p class="section-title justify-content-center"><span></span>Our Projects<span></span></p>
                    <h2 class="text-center mb-5">Recently Completed Projects</h2>
                </div>

                <!-- Dynamic Filter Buttons -->
                <div class="row mt-n2 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="col-12 text-center">
                        <ul class="list-inline mb-5" id="portfolio-flters">
                            <li class="mx-2 active" data-filter="*">All</li>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="mx-2" data-filter=".<?php echo e(Str::slug($category)); ?>"><?php echo e($category); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>

                <!-- Dynamic Projects -->
                <div class="row g-4 portfolio-container">
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $projectImages = json_decode($project->project_images, true) ?? [];

                            // Ensure thumb_image is shown first, then rest of project_images (excluding duplicate of thumb)
                            $images = array_unique(array_merge([$project->thumb_image], $projectImages));
                            $firstImage = $images[0];
                        ?>
                        
                        <div class="col-lg-4 col-md-6 portfolio-item <?php echo e(Str::slug($project->project_category_name)); ?> wow fadeInUp"
                            data-wow-delay="0.1s">
                            <div class="rounded overflow-hidden">
                                <div class="position-relative overflow-hidden">
                                    <img class="img-fluid w-100" src="<?php echo e(asset('storage/' . $firstImage)); ?>"
                                        alt="<?php echo e($project->title); ?>">
                                    <div class="portfolio-overlay">
                                        <?php if(count($images)): ?>
                                            <!-- First visible button to open lightbox -->
                                            <a class="btn btn-square btn-outline-light mx-1"
                                                href="<?php echo e(asset('storage/' . $images[0])); ?>"
                                                data-lightbox="portfolio-<?php echo e($project->id); ?>">
                                                <i class="fa fa-eye"></i>
                                            </a>

                                            <!-- Hidden links for rest of the images (for lightbox group) -->
                                            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($index > 0): ?>
                                                    <a href="<?php echo e(asset('storage/' . $img)); ?>"
                                                        data-lightbox="portfolio-<?php echo e($project->id); ?>" class="d-none"></a>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                        <?php if($project->project_url): ?>
                                            <a class="btn btn-square btn-outline-light mx-1"
                                                href="<?php echo e($project->project_url); ?>"><i class="fa fa-link"></i></a>
                                        <?php endif; ?>
                                    </div>

                                </div>
                                <div class="bg-custom p-4">
                                    <p class="text-danger fw-medium mb-2"><?php echo e($project->project_category_name); ?></p>
                                    <h5 class="lh-base mb-0"><?php echo e($project->title); ?></h5>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <!-- Projects End -->

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('component.main', ['seos' => $seos], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\realvictory\RVG-C\resources\views/front/project.blade.php ENDPATH**/ ?>