

<?php $__env->startSection('content'); ?>
<style>
  .tick-wrap{width:110px;height:110px;border-radius:50%;background:#e9f8ef;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;}
  .tick{font-size:52px;line-height:1;color:#10b981;}
  .thank-card{border-radius:18px}
  .btn-grad{background:linear-gradient(135deg,#0ea5e9,#2563eb);border:none}
  .btn-grad:hover{filter:brightness(.95)}
</style>

<!-- Header -->
<div class="container-fluid custom-color my-lg-5 py-md-4 py-sm-3 py-2">
  <div class="container text-center py-5">
    <h1 class="display-5 text-white mb-1">Thank You</h1>
    <p class="text-white-50 mb-0">Your payment has been received successfully.</p>
  </div>
</div>

<?php
  // Pull session details set in CheckoutController@verify (and clear them)
  $tk = session()->pull('thankyou');

  // Fallbacks from query string if someone hits this page directly
  $orderId   = $tk['order_id']     ?? request('order');
  $payId     = $tk['payment_id']   ?? request('pay');
  $pkgName   = $tk['package_name'] ?? request('pkg');
  $amount    = $tk['amount']       ?? null;
  $currency  = $tk['currency']     ?? 'INR';
  $paidAt    = $tk['paid_at']      ?? now()->format('d M Y, h:i A');
?>

<div class="container my-5">
  <div class="row justify-content-center">
    <div class="col-lg-8">
      <div class="card shadow-sm border-0 thank-card">
        <div class="card-body p-4 p-md-5 text-center">
          <div class="tick-wrap">
            <i class="bi bi-check2-circle tick"></i>
          </div>
          <h2 class="fw-bold mb-2">Payment Successful!</h2>
          <p class="text-muted mb-4">
            Thank you for choosing us. Your order is being processed and you’ll receive onboarding details shortly on your registered contact.
          </p>

          <div class="row g-3 justify-content-center mb-4">
            <?php if($pkgName): ?>
              <div class="col-md-4">
                <div class="p-3 rounded bg-light border h-100">
                  <div class="text-muted small">Package</div>
                  <div class="fw-semibold"><?php echo e($pkgName); ?></div>
                </div>
              </div>
            <?php endif; ?>

            <?php if($payId): ?>
              <div class="col-md-4">
                <div class="p-3 rounded bg-light border h-100">
                  <div class="text-muted small">Payment ID</div>
                  <div class="fw-semibold"><?php echo e($payId); ?></div>
                </div>
              </div>
            <?php endif; ?>

            <?php if($orderId): ?>
              <div class="col-md-4">
                <div class="p-3 rounded bg-light border h-100">
                  <div class="text-muted small">Order ID</div>
                  <div class="fw-semibold"><?php echo e($orderId); ?></div>
                </div>
              </div>
            <?php endif; ?>

            <?php if(!is_null($amount)): ?>
              <div class="col-md-4">
                <div class="p-3 rounded bg-light border h-100">
                  <div class="text-muted small">Amount</div>
                  <div class="fw-semibold">₹ <?php echo e(number_format((float)$amount, 2)); ?> <?php echo e($currency); ?></div>
                </div>
              </div>
            <?php endif; ?>

            <?php if($paidAt): ?>
              <div class="col-md-4">
                <div class="p-3 rounded bg-light border h-100">
                  <div class="text-muted small">Paid At</div>
                  <div class="fw-semibold"><?php echo e($paidAt); ?></div>
                </div>
              </div>
            <?php endif; ?>
          </div>

          <?php if(!$payId && !$orderId && !$pkgName): ?>
            <div class="alert alert-warning text-start mx-auto" style="max-width:560px">
              We couldn’t find the transaction details. If the amount is deducted, please contact support with your registered phone number.
            </div>
          <?php endif; ?>

          <div class="d-flex gap-2 justify-content-center">
  <a href="<?php echo e(url('/packages')); ?>" class="btn btn-grad text-white px-4">Browse More Packages</a>
  <a href="<?php echo e(url('/')); ?>" class="btn btn-secondary px-4">Go to Home</a>
  <a href="<?php echo e(url('/contact')); ?>" class="btn btn-success px-4">Need Help?</a>

  
  <a href="tel:+917800378002" class="btn btn-dark px-4">
    <i class="bi bi-telephone me-1"></i> Call
  </a>
  <a href="https://wa.me/+917800378002" target="_blank" class="btn btn-success px-4">
    <i class="bi bi-whatsapp me-1"></i> WhatsApp
  </a>
</div>


          <p class="small text-muted mt-4 mb-0">
            Tip: Please don’t refresh this page continuously. If the amount is deducted but the status is not updated, contact support with your Payment ID.
          </p>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('component.main', ['seos' => (object)[
  'meta_title' => 'Payment Successful | Thank You',
  'meta_description' => 'Your payment was successful. Thank you for your purchase!'
]], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\realvictory\RVG-C\resources\views/front/thankyou.blade.php ENDPATH**/ ?>