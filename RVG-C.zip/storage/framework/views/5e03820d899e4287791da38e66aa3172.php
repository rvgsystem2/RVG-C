<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <h2 class="font-bold text-2xl text-gray-800">Customer Purchases</h2>
        
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-2">
                <div class="bg-green-50 text-green-700 rounded-lg px-3 py-2 text-sm">Paid: <b><?php echo e($stats['paid']); ?></b></div>
                <div class="bg-yellow-50 text-yellow-700 rounded-lg px-3 py-2 text-sm">Created: <b><?php echo e($stats['created']); ?></b></div>
                <div class="bg-red-50 text-red-700 rounded-lg px-3 py-2 text-sm">Failed: <b><?php echo e($stats['failed']); ?></b></div>
                <div class="bg-blue-50 text-blue-700 rounded-lg px-3 py-2 text-sm">Revenue: <b>₹ <?php echo e(number_format($stats['revenue'],2)); ?></b></div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white shadow-xl rounded-2xl p-6 border border-gray-200">
                
                <form method="GET" class="grid md:grid-cols-5 gap-3 mb-5">
                    <input type="text" name="q" value="<?php echo e($q); ?>" placeholder="Search name/phone/order/payment"
                           class="md:col-span-2 w-full px-3 py-2 border border-gray-300 rounded">
                    <select name="status" class="w-full px-3 py-2 border border-gray-300 rounded">
                        <option value="">All Status</option>
                        <option value="paid" <?php echo e($status==='paid'?'selected':''); ?>>Paid</option>
                        <option value="created" <?php echo e($status==='created'?'selected':''); ?>>Created</option>
                        <option value="failed" <?php echo e($status==='failed'?'selected':''); ?>>Failed</option>
                    </select>
                    <input type="date" name="from" value="<?php echo e($from); ?>" class="w-full px-3 py-2 border border-gray-300 rounded">
                    <input type="date" name="to"   value="<?php echo e($to); ?>" class="w-full px-3 py-2 border border-gray-300 rounded">
                    <div class="md:col-span-5 flex gap-2">
                        <button class="px-4 py-2 bg-gray-900 text-white rounded">Filter</button>
                        <a href="<?php echo e(route('purchases.index')); ?>" class="px-4 py-2 bg-gray-100 rounded">Reset</a>
                    </div>
                </form>

                
                <div class="overflow-x-auto">
                    <table class="w-full text-sm text-left border border-gray-200 rounded-lg overflow-hidden">
                        <thead class="bg-gray-50 text-gray-700 uppercase font-semibold text-xs">
                            <?php
                              $toggleDir = $dir==='asc'?'desc':'asc';
                              $sortLink = fn($col) => request()->fullUrlWithQuery(['sort'=>$col,'dir'=>$toggleDir]);
                            ?>
                            <tr>
                                <th class="px-4 py-3"><a href="<?php echo e($sortLink('created_at')); ?>">Date</a></th>
                                <th class="px-4 py-3">Package</th>
                                <th class="px-4 py-3">Customer</th>
                                <th class="px-4 py-3">Phone</th>
                                <th class="px-4 py-3"><a href="<?php echo e($sortLink('amount')); ?>">Amount</a></th>
                                <th class="px-4 py-3"><a href="<?php echo e($sortLink('status')); ?>">Status</a></th>
                                <th class="px-4 py-3">Order ID</th>
                                <th class="px-4 py-3">Payment ID</th>
                                <th class="px-4 py-3 text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-100">
                            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-4 py-3 text-gray-600">
                                        <?php echo e($o->created_at->format('d M Y, h:i A')); ?>

                                    </td>
                                    <td class="px-4 py-3">
                                        <div class="font-semibold"><?php echo e($o->package->name ?? '—'); ?></div>
                                        <div class="text-xs text-gray-500">Pkg ID: <?php echo e($o->package_id); ?></div>
                                    </td>
                                    <td class="px-4 py-3">
                                        <div class="font-medium"><?php echo e($o->name ?? '—'); ?></div>
                                        <div class="text-xs text-gray-500"><?php echo e($o->business_name ?? ''); ?></div>
                                    </td>
                                    <td class="px-4 py-3"><?php echo e($o->phone); ?></td>
                                    <td class="px-4 py-3 font-semibold">₹ <?php echo e(number_format($o->amount,2)); ?></td>
                                    <td class="px-4 py-3">
                                        <span class="px-2 py-1 rounded text-xs
                                          <?php echo e($o->status==='paid' ? 'bg-green-100 text-green-700' :
                                             ($o->status==='failed' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700')); ?>">
                                          <?php echo e(ucfirst($o->status)); ?>

                                        </span>
                                    </td>
                                    <td class="px-4 py-3 text-xs"><?php echo e($o->razorpay_order_id); ?></td>
                                    <td class="px-4 py-3 text-xs"><?php echo e($o->razorpay_payment_id ?? '—'); ?></td>
                                    <td class="px-4 py-3 text-center">
                                        <a href="<?php echo e(route('purchases.show', $o->id)); ?>"
                                           class="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs">View</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="9" class="px-4 py-6 text-center text-gray-500">No purchases found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="mt-4">
                    <?php echo e($orders->links()); ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\realvictory\RVG-C\resources\views/backend/purchases/index.blade.php ENDPATH**/ ?>