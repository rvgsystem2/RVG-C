<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center bg-white shadow-md px-6 py-4 rounded-lg">
            <h2 class="font-bold text-2xl text-gray-800">
                <?php echo e(__('SEO Management')); ?>

            </h2>
            <a href="<?php echo e(route('seo.create')); ?>"
                class="px-5 py-2 bg-gradient-to-r from-green-700 to-blue-800 text-white font-semibold rounded-lg shadow-md hover:from-blue-800 hover:to-green-700 transition">
                + Add SEO
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-10">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <?php if(session('success')): ?>
                <div class="bg-green-100 text-green-800 px-4 py-3 rounded-lg mb-4 shadow">
                    ✅ <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <div class="bg-white shadow-xl rounded-2xl p-6 border border-gray-200">
                <h2 class="text-2xl font-bold text-gray-800 mb-6">SEO Entries</h2>

                <div class="overflow-x-auto">
                    <table class="w-full text-sm text-left border border-gray-200 rounded-lg overflow-hidden">
                        <thead class="bg-gray-100 text-gray-700 uppercase font-semibold text-xs">
                            <tr>
                                <th class="px-6 py-4">ID</th>
                                <th class="px-6 py-4">Title</th>
                                <th class="px-6 py-4">Page Type</th>
                                <th class="px-6 py-4">Blogs/Service</th>
                                <th class="px-6 py-4">Packages</th>
                                <th class="px-6 py-4 text-center">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-100">
                            <?php $__empty_1 = true; $__currentLoopData = $seos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="px-6 py-3 text-gray-800"><?php echo e($seo->id); ?></td>
                                    <td class="px-6 py-3"><?php echo e($seo->meta_title ?? '-'); ?></td>
                                    
                                    <td class="px-6 py-3 capitalize"><?php echo e($seo->page_type ?? '-'); ?></td>

                                    </td>
                                    <td class="px-6 py-3">
    <?php if($seo->blog): ?>
        Blog: <?php echo e($seo->blog->title); ?>

    <?php elseif($seo->serviceDetail): ?>
        Service: <?php echo e($seo->serviceDetail->title); ?>

        <?php if($seo->serviceDetail->category): ?>
            <div class="text-xs text-gray-500">
                (Category: <?php echo e($seo->serviceDetail->category->name); ?>)
            </div>
        <?php endif; ?>
    <?php elseif($seo->package): ?>
        Package: <?php echo e($seo->package->name); ?>

    <?php else: ?>
        -
    <?php endif; ?>
</td>


                                    <td class="px-6 py-3">
                                        <?php echo e($seo->blog ? 'Blog: ' . $seo->blog->title : ($seo->serviceDetail ? 'Service: ' . $seo->serviceDetail->sort_description : ($seo->package ? 'Package: ' . $seo->package->name : '-'))); ?>

                                    </td>


                                    <td class="px-6 py-3 text-center">
                                        <div class="flex justify-center gap-3">
                                            <a href="<?php echo e(route('seo.edit', $seo->id)); ?>"
                                                class="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded-md text-sm font-semibold transition shadow">
                                                ✏️ Edit
                                            </a>
                                            <form action="<?php echo e(route('seo.delete', $seo->id)); ?>" method="get"
                                                onsubmit="return confirm('Are you sure?')">
                                                <?php echo csrf_field(); ?>
                                                
                                                <button type="submit"
                                                    class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-md text-sm font-semibold transition shadow">
                                                    🗑️ Delete
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="text-center py-6 text-gray-400">
                                        No SEO entries found.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="mt-4">
                    <?php echo e($seos->links()); ?>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\realvictory\RVG-C\resources\views/seo/index.blade.php ENDPATH**/ ?>