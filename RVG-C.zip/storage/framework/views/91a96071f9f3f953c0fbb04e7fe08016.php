<html lang="en">

<head>

    <?php
        $seo = $seos ?? null;
        // dd($seos);
    ?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Title -->
    <?php if(!empty($seo?->meta_title)): ?>
        <meta name="title" content="<?php echo e($seo->meta_title); ?>">
    <?php endif; ?>

    <?php if(!empty($seo?->title)): ?>
        <title><?php echo e($seo->title); ?></title>
    <?php elseif(!empty($seo?->meta_title)): ?>
        <title><?php echo e($seo->meta_title); ?></title>
    <?php endif; ?>

    <!-- Standard SEO -->
    <?php if(!empty($seo?->meta_description)): ?>
        <meta name="description" content="<?php echo e($seo->meta_description); ?>">
    <?php endif; ?>

    <?php if(!empty($seo?->meta_keywords)): ?>
        <meta name="keywords" content="<?php echo e($seo->meta_keywords); ?>">
    <?php endif; ?>

    <?php if(!empty($seo?->robots)): ?>
        <meta name="robots" content="<?php echo e($seo->robots); ?>">
    <?php endif; ?>

    <?php if(!empty($seo?->author)): ?>
        <meta name="author" content="<?php echo e($seo->author); ?>">
    <?php endif; ?>

    <!-- Canonical & Language -->
    <?php if(!empty($seo?->canonical_url)): ?>
        <link rel="canonical" href="<?php echo e($seo->canonical_url); ?>">
    <?php endif; ?>

    <?php if(!empty($seo?->locale)): ?>
        <meta name="language" content="<?php echo e($seo->locale); ?>">
        <meta http-equiv="Content-Language" content="<?php echo e($seo->locale); ?>">
    <?php endif; ?>

    <!-- Alternate hreflang -->
    <?php if(!empty($seo?->alternate_url)): ?>
        <link rel="alternate" hreflang="<?php echo e($seo->alternate_href_lang ?? 'en'); ?>" href="<?php echo e($seo->alternate_url); ?>">
    <?php endif; ?>

    <!-- Region, Country, Timezone -->
    <?php if(!empty($seo?->country)): ?>
        <meta name="country" content="<?php echo e($seo->country); ?>">
    <?php endif; ?>
    <?php if(!empty($seo?->region)): ?>
        <meta name="region" content="<?php echo e($seo->region); ?>">
    <?php endif; ?>
    <?php if(!empty($seo?->timezone)): ?>
        <meta name="timezone" content="<?php echo e($seo->timezone); ?>">
    <?php endif; ?>

    <!-- Breadcrumb & Page Type -->
    <?php if(!empty($seo?->breadcrumb_title)): ?>
        <meta name="breadcrumb" content="<?php echo e($seo->breadcrumb_title); ?>">
    <?php endif; ?>

    <?php if(!empty($seo?->content_type)): ?>
        <meta name="content_type" content="<?php echo e($seo->content_type); ?>">
    <?php endif; ?>

    <?php if(!empty($seo?->page_type)): ?>
        <meta name="page_type" content="<?php echo e($seo->page_type); ?>">
    <?php endif; ?>

    <!-- Sitemap Hints -->
    <?php if(!empty($seo?->priority)): ?>
        <meta name="priority" content="<?php echo e($seo->priority); ?>">
    <?php endif; ?>

    <?php if(!empty($seo?->changefreq)): ?>
        <meta name="changefreq" content="<?php echo e($seo->changefreq); ?>">
    <?php endif; ?>

    <!-- Open Graph -->
    <?php if(!empty($seo?->og_title)): ?>
        <meta property="og:title" content="<?php echo e($seo->og_title); ?>">
    <?php endif; ?>

    <?php if(!empty($seo?->og_description)): ?>
        <meta property="og:description" content="<?php echo e($seo->og_description); ?>">
    <?php endif; ?>

    <?php if(!empty($seo?->og_image)): ?>
        <meta property="og:image" content="<?php echo e(asset('storage/' . $seo->og_image)); ?>">
        <meta property="og:image:secure_url" content="<?php echo e(asset('storage/' . $seo->og_image)); ?>">
    <?php endif; ?>

    <?php if(!empty($seo?->og_type)): ?>
        <meta property="og:type" content="<?php echo e($seo->og_type); ?>">
    <?php endif; ?>

    <?php if(!empty($seo?->og_url)): ?>
        <meta property="og:url" content="<?php echo e($seo->og_url); ?>">
    <?php endif; ?>

    <!-- Twitter Card -->
    <?php if(!empty($seo?->twitter_card)): ?>
        <meta name="twitter:card" content="<?php echo e($seo->twitter_card); ?>">
    <?php endif; ?>

    <?php if(!empty($seo?->twitter_title)): ?>
        <meta name="twitter:title" content="<?php echo e($seo->twitter_title); ?>">
    <?php endif; ?>

    <?php if(!empty($seo?->twitter_description)): ?>
        <meta name="twitter:description" content="<?php echo e($seo->twitter_description); ?>">
    <?php endif; ?>

    <?php if(!empty($seo?->twitter_image)): ?>
        <meta name="twitter:image" content="<?php echo e(asset('storage/' . $seo->twitter_image)); ?>">
    <?php endif; ?>

    <?php if(!empty($seo?->twitter_site)): ?>
        <meta name="twitter:site" content="<?php echo e($seo->twitter_site); ?>">
    <?php endif; ?>

    <?php if(!empty($seo?->twitter_creator)): ?>
        <meta name="twitter:creator" content="<?php echo e($seo->twitter_creator); ?>">
    <?php endif; ?>

    <!-- Focus Keyword -->
    <?php if(!empty($seo?->focus_keyword)): ?>
        <meta name="focus_keyword" content="<?php echo e($seo->focus_keyword); ?>">
    <?php endif; ?>


  

    
    <?php if(!empty($seo?->structured_data_json)): ?>
        <?php $jsonLd = str_replace('</script>', '<\/script>', $seo->structured_data_json); ?>
        <script type="application/ld+json"><?php echo $jsonLd; ?></script>
    <?php endif; ?>

    <!-- Favicon -->
    <link href="<?php echo e(asset('logo.png')); ?>" rel="icon">
    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500&family=Jost:wght@500;600;700&display=swap"
        rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <!-- Libraries Stylesheet -->
    <link href="<?php echo e(asset('front-asset/lib/animate/animate.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('front-asset/lib/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('front-asset/lib/lightbox/css/lightbox.min.css')); ?>" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    <style>
        .testimonial-item {
            transition: all 0.3s ease-in-out;
        }

        .testimonial-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .transition-scale {
            transition: transform 0.3s ease-in-out;
        }

        .transition-scale:hover {
            transform: translateY(-6px);
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
        }

        .transition-scale {
            transition: transform 0.4s ease-in-out;
        }

        .transition-scale:hover {
            transform: scale(1.05);
        }

        .product-card:hover {
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.1);
        }

        .portfolio-overlay {
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            background: rgba(0, 0, 0, 0.6);
            opacity: 0;
            transition: all 0.4s ease;
        }

        .project-card:hover .portfolio-overlay {
            opacity: 1;
        }

        #portfolio-flters button {
            transition: 0.3s;
            border-radius: 50px;
            padding: 6px 18px;
        }

        #portfolio-flters button.active,
        #portfolio-flters button:hover {
            background-color: #dc3545;
            color: #fff;
            border-color: #dc3545;
        }

        meta, meta::before, meta::after { display: none !important; content: none !important; }
    </style>

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?php echo e(asset('front-asset/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="<?php echo e(asset('front-asset/css/style.css')); ?>" rel="stylesheet">


    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-D28Z1KG941"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-D28Z1KG941');
</script>
</head>

<body>


    <?php echo $__env->make('component.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('component.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php if(session('success')): ?>
        <script>
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: "<?php echo e(session('success')); ?>",
                confirmButtonColor: '#3085d6'
            });
        </script>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: "<?php echo e(session('error')); ?>",
                confirmButtonColor: '#d33'
            });
        </script>
    <?php endif; ?>



    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('front-asset/lib/wow/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('front-asset/lib/easing/easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('front-asset/lib/waypoints/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('front-asset/lib/counterup/counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('front-asset/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('front-asset/lib/isotope/isotope.pkgd.min.js')); ?>"></script>
    <script src="<?php echo e(asset('front-asset/lib/lightbox/js/lightbox.min.js')); ?>"></script>

    <!-- Template Javascript -->
    <script src="<?php echo e(asset('front-asset/js/main.js')); ?>"></script>
</body>

</html>
<?php /**PATH D:\realvictory\RVG-C\resources\views/component/main.blade.php ENDPATH**/ ?>