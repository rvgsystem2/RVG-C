<?php $__env->startSection('content'); ?>

<!-- Page Header Start -->
<div class="container-fluid custom-color mt-lg-5 py-md-4 py-sm-3 py-2">
    <div class="container text-center py-5 ">
        <h1 class="display-2 text-white mb-4 animated slideInDown"><?php echo e($blog->title); ?></h1>
        <nav aria-label="breadcrumb animated slideInDown">
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-white">Home</a></li>
                <li class="breadcrumb-item active text-white" aria-current="page"><?php echo e($blog->title); ?></li>
            </ol>
        </nav>
    </div>
</div>
<!-- Page Header End -->

<section class="mt-lg-5 py-md-4 py-sm-3 py-2 bg-white">
    <div class="container mt-5">
        <div class="row gy-5">
            <!-- Left Column -->
            <div class="col-lg-8">
                <!-- Blog Image & Category -->
                <div class="position-relative mb-4">
                    <img src="<?php echo e(asset('storage/' . $blog->image)); ?>" class="img-fluid rounded shadow w-100" alt="<?php echo e($blog->image_alt ?? $blog->title); ?>">
                    <span class="position-absolute top-0 end-0 custom-color text-white px-4 py-2 rounded-bottom-start">
                        <?php echo e($blog->category->name ?? 'Uncategorized'); ?>

                    </span>
                </div>

                <!-- Blog Title & Meta -->
                <div class="mb-4">
                    <h2 class="fw-bold display-6"><?php echo e($blog->title); ?></h2>
                    <p class="text-muted">
                        By <strong class="text-dark"><?php echo e($blog->author ?? 'Admin'); ?></strong> |
                        <i class="far fa-calendar-alt me-1"></i> <?php echo e($blog->created_at->format('d M Y')); ?>

                    </p>
                </div>

                <!-- Blog Content -->
                <div class="mb-5 content-area">
                    <?php echo $blog->content; ?>

                </div>

                <!-- Tags & Share -->


                <!-- Author Info -->
                <div class="d-flex align-items-center mt-5 p-4 bg-white rounded shadow-sm">
                    <img src="<?php echo e(asset('front-asset/img/team-1.jpg')); ?>" class="rounded-circle me-3 border border-3 shadow" width="70" alt="Author">
                    <div>
                        <h6 class="mb-1 fw-semibold"><?php echo e($blog->author ?? 'Admin'); ?></h6>
                        <small class="text-muted">Author</small>
                    </div>
                </div>
            </div>

            <!-- Right Column: Sidebar -->
            <div class="col-lg-4">
                <!-- Latest Updates -->
                <div class="mb-5 p-4 bg-light rounded shadow-sm">
                    <h5 class="fw-bold mb-3">Latest Updates</h5>
                    <ul class="list-unstyled">
                        <?php
                            $latestBlogs = \App\Models\Blog::latest()->take(3)->get();
                        ?>
                        <?php $__currentLoopData = $latestBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="mb-2">
                                <a href="<?php echo e(route('blogdetail', $latest->slug)); ?>" class="text-decoration-none text-dark">
                                    <?php echo e($latest->title); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                <!-- Recent Blog Posts -->
                <div class="mb-5 p-4 bg-light rounded shadow-sm">
                    <h5 class="fw-bold mb-3">Recent Posts</h5>
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $latestBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item px-0 border-0">
                                <a href="<?php echo e(route('blogdetail', $recent->slug)); ?>" class="text-dark text-decoration-none">
                                    <?php echo e($recent->title); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                <!-- Important Links -->
                <div class="p-4 bg-light rounded shadow-sm">
                    <h5 class="fw-bold mb-3">Important Links</h5>
                    <div class="d-grid gap-2">
                        <a href="wa.me/+918423269465" class="btn btn-primary">Join Our WhatsApp Group</a>
                        <a href="https://www.instagram.com/realvictorygroups" class="btn btn-secondary">Instagram</a>
                        <a href="<?php echo e(route('contact')); ?>" class="btn btn-dark">Contact Support</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('component.main', ['seos' => $seos ?? null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\realvictory\RVG-C\resources\views/front/blogdetail.blade.php ENDPATH**/ ?>