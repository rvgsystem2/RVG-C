<?php $__env->startSection('content'); ?>

 <!-- Page Header Start -->
 <div class="container-fluid custom-color  my-lg-5 py-md-4 py-sm-3 py-2">
    <div class="container text-center py-5">
        <h1 class="display-2 text-white mb-4 animated slideInDown">Our Blog</h1>
        <nav aria-label="breadcrumb animated slideInDown">
            <ol class="breadcrumb justify-content-center mb-0">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Home</a></li>

                <li class="breadcrumb-item" aria-current="page"><a href="">Blog</a></li>
            </ol>
        </nav>
    </div>
</div>
<!-- Page Header End -->




   <!-- Blog Start -->
   <div class="container-fluid lg:py-5 md:py-4 sm:py-2 mb-5">
    <div class="container">
        <div class="text-center mx-auto pb-5 wow fadeIn py-5" data-wow-delay=".3s" style="max-width: 600px;">
            <h5 class="text-dark">Our Blog</h5>
            <h1>Latest Blog & News</h1>
        </div>
     <div class="row g-5 gap-5 justify-content-center">
    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-6 col-xl-3 col-md-4 wow fadeIn blog py-5" data-wow-delay=".3s">
        <div class="blog-item position-relative bg-light rounded ">
            <img src="<?php echo e(asset('storage/' . $blog->thumbnail_img)); ?>" class="img-fluid w-100 rounded-top" alt="<?php echo e($blog->thumbnail_img_alt); ?>">
            <span class="position-absolute px-4 py-2 custom-color text-white rounded" style="top: -28px; right: 20px;">
                <?php echo e($blog->category->name ?? 'Uncategorized'); ?>

            </span>

            <div class="d-flex align-items-start p-2 mt-3 mb-2">
                <!-- Author Image -->
                <img src="<?php echo e(asset('front-asset/img/team-1.jpg')); ?>" alt="Author" class="rounded-circle me-3" width="60" height="60" style="object-fit: cover;">

                <!-- Content -->
                <div class="flex-grow-1">
                    <div class="d-flex justify-content-around align-items-center mb-1">
                        <h6 class="mb-0"><?php echo e($blog->author ?? 'Admin'); ?></h6>
                        <small class="text-muted"><?php echo e($blog->created_at->format('d M Y')); ?></small>
                    </div>
                    <p class="mb-0 text-muted"><?php echo e(Str::limit(strip_tags($blog->sort_content), 120)); ?></p>
                </div>
            </div>

            <div class="blog-btn d-flex justify-content-center px-3 mt-0 w-100">
                <a href="<?php echo e(route('blogdetail', $blog->slug)); ?>" class="btn btn-dark rounded-pill text-white w-100 px-3 py-2">
                    Read More
                </a>
            </div>

            
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<!-- Pagination -->
<div class="text-center mt-4">
    <?php echo e($blogs->links('pagination::bootstrap-5')); ?>

</div>

    </div>
</div>
<!-- Blog End -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('component.main', ['seos' => $seos], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\realvictory\RVG-C\resources\views/front/blog.blade.php ENDPATH**/ ?>