<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center bg-white shadow-md px-6 py-4 rounded-lg">
            <h2 class="font-bold text-2xl text-gray-800">Interested Leads</h2>

            
            
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-10">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">

            
            <?php if(session('success')): ?>
                <div class="flex items-center gap-2 bg-green-100 text-green-700 px-4 py-3 rounded-lg shadow-sm">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                    </svg>
                    <span><?php echo e(session('success')); ?></span>
                </div>
            <?php endif; ?>

            
            <div class="bg-white shadow-xl rounded-2xl border border-gray-200">
                <div class="px-6 pt-6 pb-4 flex flex-wrap items-center justify-between gap-3">
                    <div>
                        <h3 class="text-xl font-semibold text-gray-800">All Leads</h3>
                        <p class="text-sm text-gray-500">Total: <?php echo e($leads->total()); ?></p>
                    </div>

                    
                    
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-sm text-left border-t border-gray-200">
                        <thead class="bg-gray-50 text-gray-700 uppercase text-xs">
                            <tr>
                                <th class="px-6 py-3">ID</th>
                                <th class="px-6 py-3">Package</th>
                                <th class="px-6 py-3">Phone</th>
                                <th class="px-6 py-3">Source</th>
                                <th class="px-6 py-3">Created (IST)</th>
                                <th class="px-6 py-3 text-center">Quick Actions</th>
                                <th class="px-6 py-3 text-center">Manage</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    $pkg   = $lead->package;
                                    $pname = $pkg->name ?? '—';
                                    // normalize phone to digits; prepend 91 if 10 digits
                                    $digits = preg_replace('/\D+/', '', (string) $lead->phone);
                                    $wa = (strlen($digits) === 10) ? '91'.$digits : $digits;
                                    $tel = '+'.$wa;
                                ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 font-medium text-gray-800">#<?php echo e($lead->id); ?></td>

                                    <td class="px-6 py-4">
                                        <div class="flex items-start gap-2">
                                            <div>
                                                <div class="font-semibold text-gray-900"><?php echo e($pname); ?></div>
                                                <?php if($pkg): ?>
                                                    <div class="text-xs text-gray-500">ID: <?php echo e($pkg->id); ?></div>
                                                <?php else: ?>
                                                    <div class="text-xs text-red-500">Package removed</div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>

                                    <td class="px-6 py-4">
                                        <div class="flex items-center gap-2">
                                            <a href="tel:<?php echo e($tel); ?>" class="text-gray-800 font-medium hover:underline">
                                                <?php echo e($lead->phone); ?>

                                            </a>
                                            <button type="button"
                                                    class="text-xs px-2 py-1 rounded bg-gray-100 hover:bg-gray-200"
                                                    onclick="copyToClipboard('<?php echo e($lead->phone); ?>')">
                                                Copy
                                            </button>
                                        </div>
                                    </td>

                                    <td class="px-6 py-4">
                                        <span class="px-2 py-1 text-xs rounded-full bg-gray-100 text-gray-700">
                                            <?php echo e($lead->source ?? 'package-details'); ?>

                                        </span>
                                    </td>

                                    <td class="px-6 py-4 text-gray-700">
                                        <?php echo e(optional($lead->created_at)->timezone('Asia/Kolkata')->format('d M Y, h:i A')); ?>

                                    </td>

                                    <td class="px-6 py-4">
                                        <div class="flex items-center justify-center gap-2">
                                            <a href="tel:<?php echo e($tel); ?>"
                                               class="px-3 py-1.5 rounded-lg bg-slate-800 text-white text-xs hover:bg-slate-700">
                                                Call
                                            </a>
                                            <?php if($wa): ?>
                                                <a href="https://wa.me/<?php echo e($wa); ?>?text=<?php echo e(rawurlencode('Hi! We received your interest. How can we help you?')); ?>"
                                                   target="_blank"
                                                   class="px-3 py-1.5 rounded-lg bg-green-600 text-white text-xs hover:bg-green-700">
                                                    WhatsApp
                                                </a>
                                            <?php endif; ?>
                                            <?php if($pkg): ?>
                                                <a href="<?php echo e(route('packages.details', $pkg->id)); ?>"
                                                   class="px-3 py-1.5 rounded-lg border text-xs hover:bg-gray-50">
                                                    View Package
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </td>

                                    <td class="px-6 py-4">
                                        <div class="flex items-center justify-center gap-2">
                                            
                                            <form action="<?php echo e(route('admin.leads.destroy', $lead->id)); ?>" method="get"
                                                  onsubmit="return confirm('Delete this lead?')">
                                                
                                                <button type="submit"
                                                        class="px-3 py-1.5 rounded-lg bg-red-500 text-white text-xs hover:bg-red-600">
                                                    Delete
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="px-6 py-10 text-center text-gray-500">
                                        No leads found.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="px-6 py-4">
                    <?php echo e($leads->links()); ?>

                </div>
            </div>
        </div>
    </div>

    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
      function copyToClipboard(text){
        if(navigator.clipboard && window.isSecureContext){
          navigator.clipboard.writeText(text).then(()=>{
            Swal.fire({toast:true, position:'top-end', icon:'success', title:'Copied', showConfirmButton:false, timer:1200});
          });
        } else {
          const ta = document.createElement('textarea');
          ta.value = text; document.body.appendChild(ta);
          ta.select(); document.execCommand('copy'); ta.remove();
          Swal.fire({toast:true, position:'top-end', icon:'success', title:'Copied', showConfirmButton:false, timer:1200});
        }
      }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\realvictory\RVG-C\resources\views/admin/leads/index.blade.php ENDPATH**/ ?>