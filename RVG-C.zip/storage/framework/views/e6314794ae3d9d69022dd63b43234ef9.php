

<nav class="container-fluid navbar navbar-expand-lg navbar-light bg-white px-4 px-lg-5 py-3 py-lg-0 ">
    <a href="/" class="navbar-brand p-0">
        
        
        <img src="<?php echo e(asset('asset/img/logo-w-removebg-preview.png')); ?>" alt="Logo" class="logo">

        <!-- <img src="img/logo.png" alt="Logo"> -->
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
        <span class="fa fa-bars"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
        <div class="navbar-nav mx-auto py-0">
            <a href="/" class="nav-item nav-link <?php echo e(request()->is('/') ? 'active ' : ''); ?>">
                Home
            </a>
             <a href="<?php echo e(route('packages')); ?>" class="nav-item nav-link <?php echo e(request()->is('packages') ? 'active ' : ''); ?>">
                Packages
            </a>
            <a href="<?php echo e(route('about')); ?>" class="nav-item nav-link <?php echo e(request()->routeIs('about') ? 'active ' : ''); ?>">
                About
            </a>
            <a href="<?php echo e(route('blog')); ?>" class="nav-item nav-link <?php echo e(request()->routeIs('blog') ? 'active ' : ''); ?>">
                Blog
            </a>
            <a href="<?php echo e(route('service')); ?>" class="nav-item nav-link <?php echo e(request()->routeIs('service') ? 'active ' : ''); ?>">
                Service
            </a>
            <a href="<?php echo e(route('project')); ?>" class="nav-item nav-link <?php echo e(request()->routeIs('project') ? 'active ' : ''); ?>">
                Project
            </a>
            <a href="<?php echo e(route('contact')); ?>" class="nav-item nav-link <?php echo e(request()->routeIs('contact') ? 'active ' : ''); ?>">
                Contact
            </a>
            <a href="<?php echo e(route('application')); ?>" class="nav-item nav-link <?php echo e(request()->routeIs('contact') ? 'active ' : ''); ?>">
                Application
            </a>
        </div>
        <button style="background-color: #040505; color: white;" class=" w-auto rounded-pill py-2 px-4 px-sm-3 mt-3 mt-sm-0">
            <a href="https://post.realvictorygroups.com/" class="text-white">  Download Your Post</a>
        </button>

    </div>
</nav>
<?php /**PATH D:\realvictory\RVG-C\resources\views/component/header.blade.php ENDPATH**/ ?>