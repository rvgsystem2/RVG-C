<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(isset($seo) ? 'Edit SEO' : 'Create SEO'); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-10">
        <div class="max-w-6xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white p-6 rounded-lg shadow-md">

                <?php if($errors->any()): ?>
                    <div class="bg-red-100 text-red-700 px-4 py-2 rounded mb-4">
                        <ul class="list-disc list-inside">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(isset($seo) ? route('seo.update', $seo->id) : route('seo.store')); ?>" method="POST"
                    enctype="multipart/form-data" class="space-y-6">
                    <?php echo csrf_field(); ?>


                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                        <div>
                            <label for=""> Title</label>
                            <input type="text" name="title" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Title" value="<?php echo e(old('title', $seo->title ?? '')); ?>"> 
                        </div>

                      
                        <div>
                            <label for=""> Meta Title</label>
                            <input type="text" name="meta_title" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Meta Title" value="<?php echo e(old('meta_title', $seo->meta_title ?? '')); ?>">
                        </div>


                        <div>
                            <label for=""> Meta Description</label>
                            <textarea name="meta_description" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Meta Description"><?php echo e(old('meta_description', $seo->meta_description ?? '')); ?></textarea>
                        </div>

                        <div>
                            <label for=""> Meta Keywords</label>
                            <input type="text" name="meta_keywords" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Meta Keywords" value="<?php echo e(old('meta_keywords', $seo->meta_keywords ?? '')); ?>">
                        </div>

                        <div>
                            <label for="">Canonical URL</label>
                            <input type="text" name="canonical_url" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Canonical URL" value="<?php echo e(old('canonical_url', $seo->canonical_url ?? '')); ?>">
                        </div>

                        <div>
                            <label for=""> Robots</label>
                            <input type="text" name="robots" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Robots" value="<?php echo e(old('robots', $seo->robots ?? '')); ?>">
                        </div>

                        <div>
                            <label for="">og_title</label>
                            <input type="text" name="og_title" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter og_title" value="<?php echo e(old('og_title', $seo->og_title ?? '')); ?>"> 

                        </div>

                        <div>
                            <label for="">og_description</label>
                            <input type="text" name="og_description" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter og_description" value="<?php echo e(old('og_description', $seo->og_description ?? '')); ?>">
                        </div>

                        <div>
                            <label for="og_type">Og type</label>
                            <input type="text" name="og_type" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter og type" value="<?php echo e(old('og_type', $seo->og_type ?? '')); ?>"> 
                        </div>
                        <div>
                            <label for="og_url">Og URL</label>
                            <input type="text" name="og_url" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter og URL" value="<?php echo e(old('og_url', $seo->og_url ?? '')); ?>">
                        </div>

                  
                          <div>
                            <label for="twitter_card">Twitter Card</label>
                            <input type="text" name="twitter_card" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Twitter Card" value="<?php echo e(old('twitter_card', $seo->twitter_card ?? '')); ?>"> 
                          </div>

                        <div>
                            <label for="twitter_title">Twitter Title</label>
                            <input type="text" name="twitter_title" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Twitter Title" value="<?php echo e(old('twitter_title', $seo->twitter_title ?? '')); ?>">
                        </div>

                        <div>
                            <label for="twitter_description">Twitter Description</label>
                            <input type="text" name="twitter_description" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Twitter Description" value="<?php echo e(old('twitter_description', $seo->twitter_description ?? '')); ?>">
                        </div>

                        <div>
                            <label for="twitter_site">Twitter Site</label>
                            <input type="text" name="twitter_site" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Twitter Site" value="<?php echo e(old('twitter_site', $seo->twitter_site ?? '')); ?>">
                        </div>

                        <div>
                            <label for="twitter_creator">Twitter Creator</label>
                            <input type="text" name="twitter_creator" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Twitter Creator" value="<?php echo e(old('twitter_creator', $seo->twitter_creator ?? '')); ?>">
                        </div>

   
                        <div>
                            <label for="schema_type">Schema Type</label>
                            <input type="text" name="schema_type" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Schema Type" value="<?php echo e(old('schema_type', $seo->schema_type ?? '')); ?>">
                        </div>

                        <div>
                            <label for="structured_data_json">Structured Data JSON</label>
                            <textarea name="structured_data_json" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Structured Data JSON"><?php echo e(old('structured_data_json', $seo->structured_data_json ?? '')); ?></textarea>
                        </div>

                       
                        <div>
                            <label for="focus_keyword">Focus Keyword</label>
                            <input type="text" name="focus_keyword" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Focus Keyword" value="<?php echo e(old('focus_keyword', $seo->focus_keyword ?? '')); ?>">
                        </div>

                        <div>
                            <label for="meta_tags">Meta Tags</label>
                            <textarea name="meta_tags" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Meta Tags"><?php echo e(old('meta_tags', $seo->meta_tags ?? '')); ?></textarea>
                        </div>

                      

                        <div>
                            <label for="breadcrumb_title">Breadcrumb Title</label>
                            <input type="text" name="breadcrumb_title" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Breadcrumb Title" value="<?php echo e(old('breadcrumb_title', $seo->breadcrumb_title ?? '')); ?>">
                        </div>

                        <div>
                            <label for="content_type">Content Type</label>
                            <input type="text" name="content_type" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Content Type" value="<?php echo e(old('content_type', $seo->content_type ?? '')); ?>">
                        </div>

                        <div>
                            <label for="author">Author</label>
                            <input type="text" name="author" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Author Name" value="<?php echo e(old('author', $seo->author ?? '')); ?>">
                        </div>

                       



                        <div>
                            <label for="priority">Priority</label>
                            <input type="text" name="priority" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Priority (0.1 to 1.0)" value="<?php echo e(old('priority', $seo->priority ?? '')); ?>">
                        </div>

                        <div>
                            <label for="changefreq">Change Frequency</label>
                            <input type="text" name="changefreq" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Change Frequency (daily, weekly, monthly)" value="<?php echo e(old('changefreq', $seo->changefreq ?? '')); ?>">
                        </div>




                        <div>
                            <label for="page_type">Page Type</label>
                            <select name="page_type" id="page_type">
                                <option value="">none</option>
                                <option value="home" <?php echo e(old('page_type', $seo->page_type ?? '') == 'home' ? 'selected' : ''); ?>>Home</option>
                                <option value="about" <?php echo e(old('page_type', $seo->page_type ?? '') == 'about' ? 'selected' : ''); ?>>About</option>
                                <option value="service" <?php echo e(old('page_type', $seo->page_type ?? '') == 'service' ? 'selected' : ''); ?>>Service</option>
                                <option value="packages" <?php echo e(old('page_type', $seo->page_type ?? '') == 'packages' ? 'selected' : ''); ?>>Packages</option>

                                <option value="blog" <?php echo e(old('page_type', $seo->page_type ?? '') == 'blog' ? 'selected' : ''); ?>>Blog</option>

                                <option value="project" <?php echo e(old('page_type', $seo->page_type ?? '') == 'project' ? 'selected' : ''); ?>>Project</option>
                                <option value="contact" <?php echo e(old('page_type', $seo->page_type ?? '') == 'contact' ? 'selected' : ''); ?>>Contact</option>

                                <option value="career" <?php echo e(old('page_type', $seo->page_type ?? '') == 'career' ? 'selected' : ''); ?>>Career</option>
                                <option value="packagesCategory" <?php echo e(old('page_type', $seo->page_type ?? '') == 'packagesCategory' ? 'selected' : ''); ?>>Packages Category</option>

                                <option value="term_and_condition" <?php echo e(old('page_type', $seo->page_type ?? '') == 'term_and_condition' ? 'selected' : ''); ?>>Term and Condition</option>

                                <option value="privacy_policy" <?php echo e(old('page_type', $seo->page_type ?? '') == 'privacy_policy' ? 'selected' : ''); ?>>Privacy Policy</option>

                                <option value="return_policy" <?php echo e(old('page_type', $seo->page_type ?? '') == 'return_policy' ? 'selected' : ''); ?>>Return Policy</option>

                                <option value="refund_policy" <?php echo e(old('page_type', $seo->page_type ?? '') == 'refund_policy' ? 'selected' : ''); ?>>Refund Policy</option>

                               
                             </select>
                        </div>


                        <div>
                            <label for="locale">Locale</label>
                            <input type="text" name="locale" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Locale (e.g., en, fr)" value="<?php echo e(old('locale', $seo->locale ?? '')); ?>">
                        </div>

                        <div>
                            <label for="country">Country</label>
                            <input type="text" name="country" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Country (default: India)" value="<?php echo e(old('country', $seo->country ?? 'India')); ?>">
                        </div>

                        <div>
                            <label for="region">Region</label>
                            <input type="text" name="region" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Region (optional)" value="<?php echo e(old('region', $seo->region ?? '')); ?>">
                        </div>

                        <div>
                            <label for="timezone">Timezone</label>
                            <input type="text" name="timezone" class="w-full px-4 py-2 border rounded-lg" placeholder="Enter Timezone" value="<?php echo e(old('timezone', $seo->timezone ?? 'UTC')); ?>">
                        </div>  


                      <div>
                            <label class="block font-medium">Link to Blog</label>
                            <select name="blog_id" class="w-full px-4 py-2 border rounded-lg">
                                <option value="">None</option>
                                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($blog->id); ?>"
                                        <?php echo e(old('blog_id', $seo->blog_id ?? '') == $blog->id ? 'selected' : ''); ?>>
                                        <?php echo e($blog->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div>
                            <label class="block font-medium">Link to Package</label>
                            <select name="package_id" class="w-full px-4 py-2 border rounded-lg">
                                <option value="">None</option>
                                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($package->id); ?>"
                                        <?php echo e(old('package_id', $seo->package_id ?? '') == $package->id ? 'selected' : ''); ?>>
                                        <?php echo e($package->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div>
                            <label class="block font-medium">Link to Service</label>
                            <select name="service_id" class="w-full px-4 py-2 border rounded-lg">
                                <option value="">None</option>
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($service->id); ?>"
                                        <?php echo e(old('service_id', $seo->service_id ?? '') == $service->id ? 'selected' : ''); ?>>
                                        <?php echo e($service->title); ?>

                                        <?php if($service->category): ?>
                                            (<?php echo e($service->category->name); ?>)
                                        <?php endif; ?>
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
                        <?php $__currentLoopData = [
        'meta_image_file' => 'meta_image',
        'og_image_file' => 'og_image',
        'twitter_image_file' => 'twitter_image',
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input => $dbField): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <label
                                    class="block font-medium"><?php echo e(ucwords(str_replace('_file', '', str_replace('_', ' ', $input)))); ?></label>
                                <input type="file" name="<?php echo e($input); ?>" class="block w-full mt-2">
                                <?php if(isset($seo) && $seo->$dbField): ?>
                                    <img src="<?php echo e(asset('storage/' . $seo->$dbField)); ?>"
                                        class="mt-2 w-24 rounded shadow">
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="pt-6">
                        <button type="submit"
                            class="px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition">
                            <?php echo e(isset($seo) ? 'Update SEO' : 'Create SEO'); ?>

                        </button>
                    </div>
                </form>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\realvictory\RVG-C\resources\views/seo/form.blade.php ENDPATH**/ ?>